// Generate Rust bindings for these header files:
#include <bsp/display.h>
#include <bsp/esp-bsp.h>
#include <bsp/touch.h>
